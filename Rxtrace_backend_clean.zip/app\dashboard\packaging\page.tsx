import { redirect } from 'next/navigation';

export default function PackagingRedirectPage() {
  redirect('/dashboard/packing-rules');
}
