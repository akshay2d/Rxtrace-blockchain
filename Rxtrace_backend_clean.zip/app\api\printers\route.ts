// app/api/printers/route.ts
import { NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase/admin';

// Server-side SUPABASE service role client (use env var with SERVICE ROLE KEY)
function getSupabaseClient() {
  return getSupabaseAdmin();
}

// Basic ID validation
function isValidPrinterId(id: string) {
  return /^[A-Z0-9-]{2,20}$/.test(id);
}

// GET: list printers (public or admin; here we return active printers)
export async function GET() {
  try {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('printers')
      .select('id, printer_id, name, is_active, registered_at')
      .order('printer_id', { ascending: true });

    if (error) {
      console.error('Supabase GET printers error', error);
      return NextResponse.json({ message: 'Failed to fetch printers' }, { status: 500 });
    }
    return NextResponse.json(data ?? [], { status: 200 });
  } catch (err: any) {
    console.error('GET /api/printers', err);
    return NextResponse.json({ message: err.message || 'Internal error' }, { status: 500 });
  }
}

// POST: bulk upsert printers
export async function POST(req: Request) {
  try {
    // you should enforce auth/roles here in production (see notes)
    const body = await req.json();
    const printers = body?.printers;
    if (!Array.isArray(printers) || printers.length === 0) {
      return NextResponse.json({ message: 'printers array required' }, { status: 400 });
    }

    // normalize & validate
    const rows: any[] = [];
    for (const p of printers) {
      const raw = (p.id || p.printer_id || '').toString().toUpperCase().trim();
      if (!isValidPrinterId(raw)) {
        return NextResponse.json({ message: `Invalid printer id: ${raw}` }, { status: 400 });
      }
      rows.push({
        printer_id: raw,
        name: p.name ?? 'Printer',
        is_active: p.active === false ? false : true,
      });
    }

    // Supabase upsert (onConflict 'printer_id')
    // NOTE: upsert will insert or update rows with matching 'printer_id'
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('printers')
      .upsert(rows, { onConflict: 'printer_id' })
      .select();

    if (error) {
      console.error('Supabase upsert printers error', error);
      return NextResponse.json({ message: error.message || 'Failed to save printers' }, { status: 500 });
    }

    return NextResponse.json(data ?? [], { status: 200 });
  } catch (err: any) {
    console.error('POST /api/printers error', err);
    return NextResponse.json({ message: err.message || 'Invalid request' }, { status: 500 });
  }
}
